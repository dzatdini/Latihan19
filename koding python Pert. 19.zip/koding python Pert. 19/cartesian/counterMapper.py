#!/home/ubuntu/anaconda3/bin/python

import sys
counter = 0

for line in sys.stdin:
    counter += 1
print(counter)
